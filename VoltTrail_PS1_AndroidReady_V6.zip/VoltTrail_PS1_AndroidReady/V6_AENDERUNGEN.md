# V6 - Quellcode-Korrektur (statisch geprüft)

Die Datei src/main.c basiert auf der zuletzt separat hochgeladenen main.c.

Korrekturen:
- OT_LEN von der nicht gesicherten Makroform auf 256 Einträge geändert.
- Renderreihenfolge: DrawOTag ab letztem Eintrag der Reverse-Ordering-Table.
- GTE-Dreiecksprojektion via gte_rtpt/stsxy statt unsicherem RotTransPers-Aufruf.
- Tiefe der Dreiecke mit gte_avsz3 zum Einsortieren ins OT verwendet.
- Front-Clipping und Kamera-Z-Achse korrigiert.
- PadInit(0) eingefügt und Standard-PS1-Tastenbits für D-Pad, X und O verwendet.
- Einmal-Aktionen nur bei neu gedrückter Taste, Bewegung weiterhin bei Halten.
- Render-Paket-Speicher doppelt angelegt und GPU-Synchronisierung vor Wiederverwendung.
- Nie verwendete Scratchpad-Funktion entfernt.

Status: Zip-Inhalt und Quelltext statisch überprüft, aber NICHT mit einem
PSn00bSDK-Crosscompiler gebaut oder im Emulator gestartet. Ein fehlgeschlagener
Github-Actions-Build ist möglich. Dann das Buildprotokoll zur Fehlerkorrektur
verwenden. Die originale V5-Datei bleibt unverändert.
