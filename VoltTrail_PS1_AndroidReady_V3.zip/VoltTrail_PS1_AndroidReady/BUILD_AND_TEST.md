# Build and emulator test checklist

## 1. Install the tools (Windows or Linux)

1. Install CMake 3.21 or newer: https://cmake.org/download/
2. Download the latest prebuilt PSn00bSDK ZIP for your operating system: https://github.com/Lameguy64/PSn00bSDK/releases
3. Extract it to a short path, e.g. `C:\\PSn00bSDK` or `/opt/psn00bsdk`.
4. Add the SDK's `bin` folder to PATH. The SDK's CMake toolchain should exist at `lib/libpsn00b/cmake/sdk.cmake`.
5. Verify `cmake --version` and `mipsel-none-elf-gcc --version`.

## 2. Build the project

Extract this project folder, open a terminal in its root (the folder containing `CMakeLists.txt`) and run:

Linux:
```sh
export PSN00BSDK=/opt/psn00bsdk
./build.sh
```

Windows PowerShell (adjust the SDK path if needed):
```powershell
$env:PSN00BSDK = "C:/PSn00bSDK"
cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE="$env:PSN00BSDK/lib/libpsn00b/cmake/sdk.cmake"
cmake --build build
```

The project is configured to create a PlayStation disc image through `iso.xml`. After a successful build, look in `build` for `VTRAIL.cue`, `VTRAIL.bin`, and the executable. Exact intermediate paths may depend on the installed PSn00bSDK version.

## 3. Test in RetroArch

1. Install/update a PlayStation core such as Beetle PSX or PCSX-ReARMed in RetroArch.
2. Choose **Load Content** and select `VTRAIL.cue`. Keep the matching `.bin` alongside it.
3. Test boot, movement, encounter/attack/capture, recovery and area transitions.

## Known status

The source has not been compiled or tested in an emulator in the environment that generated this ZIP. A successful compile is not the same as emulator validation. If the build fails, save the full terminal output so the source or build setup can be corrected.
