# Build from an Android phone (cloud build)

You do **not** need to install a compiler on Android. The included GitHub Actions workflow asks a temporary GitHub-hosted Linux machine to build the project. The first run may reveal SDK/API incompatibilities that need a code fix.

## One-time setup on your phone

1. Sign in to GitHub in your browser and create a **new private repository** named `volt-trail-ps1`. Do not upload the original Pokémon ROM; this project is original and does not use it.
2. Upload the contents of this project folder to the repository. Make sure `CMakeLists.txt`, `iso.xml`, `system.cnf`, `src/main.c`, and `.github/workflows/build-ps1.yml` are at the repository root/paths shown here—not nested inside another `VoltTrail_PS1` folder.
   - If GitHub's mobile upload screen hides dot-folders, the workflow file may be skipped. In that case create `.github/workflows/build-ps1.yml` in GitHub's web editor and paste in the file from this project.
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. Choose **Build Volt Trail PS1 image** → **Run workflow** → **Run workflow**.
5. Open the new run. If it succeeds, scroll to **Artifacts** and download `VoltTrail-PS1-build`.
6. Extract the downloaded artifact ZIP on your phone. Load the `.cue` file in RetroArch using a PlayStation core such as PCSX-ReARMed or Beetle PSX. Keep the matching `.bin` file in the same folder.

## If the workflow fails

Open the failed run, expand the red step, and copy the error text here. The workflow log is enough to diagnose most build issues. A successful compile still does not prove the game works correctly in RetroArch; runtime testing is still needed.

## Important limitations

- The source is a small original low-poly prototype, not a finished Pokémon game or a conversion of the uploaded Game Boy ROM.
- The current environment does not contain the PSn00bSDK MIPS compiler or `mkpsxiso`, so I cannot honestly claim that a PS1 image has already been built or tested here.
- This workflow downloads the latest Linux PSn00bSDK ZIP dynamically. If the release asset naming or package layout changes, the SDK-download step may need adjustment.
