#!/usr/bin/env sh
set -eu
if [ -z "${PSN00BSDK:-}" ]; then
  echo "Set PSN00BSDK to the extracted PSn00bSDK directory first." >&2
  echo "Example: export PSN00BSDK=/opt/psn00bsdk" >&2
  exit 2
fi
TOOLCHAIN="$PSN00BSDK/lib/libpsn00b/cmake/sdk.cmake"
if [ ! -f "$TOOLCHAIN" ]; then
  echo "Cannot find PSn00bSDK CMake toolchain: $TOOLCHAIN" >&2
  echo "Check that PSN00BSDK points to the SDK root folder." >&2
  exit 2
fi
cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN"
cmake --build build
