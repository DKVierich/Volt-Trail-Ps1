# Volt Trail: Shards of the Storm — PS1 homebrew prototype

An original low-poly creature-adventure prototype intended for the original PlayStation and RetroArch. It is **not** a patch or conversion of the uploaded Game Boy ROM and contains no Nintendo/Game Freak assets.

## Prototype features in source
- Flat-shaded 3D scene and D-pad movement
- Original companion Sparkit with level-based visual evolution into Voltigon
- Original wild creature Mosslet
- Turn-based encounters, attack/capture attempts, enemy responses and health
- Three themed areas: Sunmeadow, Crystal Pass and Storm Arena
- Trainer encounters, an arena leader and a badge flag
- Victory/recovery states and HUD

## Controls
- D-pad: move while exploring
- Cross (X): start an encounter / attack / continue after victory / recover after defeat
- Circle (O): attempt to capture a wild creature
- Start: reset the run

## Building
- Windows/Linux with PSn00bSDK: see `BUILD_AND_TEST.md`.
- Android only: see `ANDROID_BUILD_GUIDE.md` for a GitHub Actions cloud-build route.

## Honest status
This is still a prototype. It has not been compiled or run in a PS1 emulator in the environment that generated this package. The current environment lacks `mipsel-none-elf-gcc` and `mkpsxiso`, so no verified bootable image is included. Geometry is placeholder-like; textures, finished audio, persistent saves, inventory, dialogue, full party UI and a complete quest are not implemented.
