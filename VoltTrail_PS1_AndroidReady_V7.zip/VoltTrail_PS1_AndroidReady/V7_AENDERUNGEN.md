# V7 - GitHub-Actions-Compilerkorrektur

Ausgangspunkt ist das zuvor veröffentlichte V6-Projekt. Gemeldeter GitHub-Actions-Fehler:
`PADRright undeclared` in `src/main.c` (sowie gleichartige Pad-Namen).

Anpassungen:
- psxpad.h und psxapi.h eingebunden (PSn00bSDK).
- PADRright etc. durch PAD_CIRCLE, PAD_CROSS, PAD_LEFT/RIGHT/UP/DOWN, PAD_START ersetzt.
- Nicht vorhandene PadInit()/PadRead()-Aufrufe durch InitPAD(), StartPAD(), ChangeClearPAD(0)
  und Auslesen des PADTYPE-Puffers ersetzt.
- Tastenbits bei gültigem Controllerstatus invertiert, da der BIOS-Treiber active-low liefert.
- Bewegliche Spielfigur und Begleiter relativ zur Kameraposition gezeichnet.
- Vorhandene Spielmechanik, Level und Rendering weitgehend unverändert belassen.

Prüfung: ZIP lesbar, gezielte statische Prüfung, Host-Syntaxcheck mit
reduzierten PS1-Header-Stubs; kein echter PSn00bSDK-Crosscompile oder Emulatorlauf.
GitHub Actions muss den nächsten vollständigen Build bestätigen.

WICHTIG: Alte V6-ZIP im Repository entfernen, damit der bestehende Workflow
nicht versehentlich eine ältere VoltTrail_PS1_AndroidReady*.zip auswählt.
