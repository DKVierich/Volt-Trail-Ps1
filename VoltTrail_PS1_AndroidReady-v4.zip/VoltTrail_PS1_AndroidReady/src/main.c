#include <sys/types.h>
#include <psxgpu.h>
#include <psxgte.h>
#include <psxpad.h>
#include <psxapi.h>
#include <psxetc.h>
#include <inline_c.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OT_LEN  OT_LENGTH(8)
#define SCREEN_W 320
#define SCREEN_H 240
#define WORLD_LIMIT 500

static DISPENV disp[2];
static DRAWENV draw[2];
static u_long ot[2][OT_LEN];
static int db = 0;
static unsigned char prim_arena[65536] __attribute__((aligned(4)));
static unsigned int prim_used = 0;
static int px = 0, pz = 0;
static int facing = 0;
static int encounter = 0;
static int message_ticks = 0;
static int companion_level = 5;
static int companion_hp = 24;
static int wild_hp = 16;
static int game_mode = 0; /* 0 explore, 1 battle, 2 win */
static int step_count = 0;
static int caught_mosslet = 0;
static int badges = 0;
static int trainer_wins = 0;
static int evolved = 0;
static int region = 0; /* 0 meadow, 1 crystal pass, 2 storm arena */
static int encounter_kind = 0; /* 0 wild, 1 trainer, 2 arena leader */
static int enemy_level = 3;
static int enemy_max_hp = 16;
static int enemy_turn = 0;
static int capture_attempts = 3;
static int last_action = 0;
static int action_flash = 0;

/* BIOS-managed controller buffers (34 bytes per port). */
static uint8_t pad_buff[2][34];

/* A deliberately small, original low-poly PS1 prototype. No ROM data is used. */
static SVECTOR cube[8] = {
    {-16,-16,-16,0},{16,-16,-16,0},{16,16,-16,0},{-16,16,-16,0},
    {-16,-16,16,0},{16,-16,16,0},{16,16,16,0},{-16,16,16,0}
};

static void draw_triangle3(SVECTOR *v0, SVECTOR *v1, SVECTOR *v2, int r, int g, int b) {
    long sxy0, sxy1, sxy2, p;
    POLY_F3 *poly;
    unsigned int aligned = (prim_used + 3u) & ~3u;
    if (aligned + sizeof(POLY_F3) > sizeof(prim_arena)) return;
    poly = (POLY_F3*)(prim_arena + aligned);
    prim_used = aligned + sizeof(POLY_F3);
    setPolyF3(poly);
    setRGB0(poly, r, g, b);
    /* Project all three vertices with the PSn00bSDK GTE inline API. */
    gte_ldv3(v0, v1, v2);
    gte_rtpt();
    gte_stsxy0((long*)&sxy0);
    gte_stsxy1((long*)&sxy1);
    gte_stsxy2((long*)&sxy2);
    setXY3(poly, (short)(sxy0 & 0xffff), (short)(sxy0 >> 16),
                  (short)(sxy1 & 0xffff), (short)(sxy1 >> 16),
                  (short)(sxy2 & 0xffff), (short)(sxy2 >> 16));
    addPrim(ot[db], poly);
}

static void draw_ground(void) {
    /* Perspective-ish tiled field built from flat triangles; GTE handles projection. */
    int z, x;
    for (z = 80; z <= 420; z += 55) {
        for (x = -220; x < 221; x += 55) {
            SVECTOR a = {x, 35, z, 0};
            SVECTOR b = {x + 55, 35, z, 0};
            SVECTOR c = {x, 35, z + 55, 0};
            SVECTOR d = {x + 55, 35, z + 55, 0};
            /* Translate the view by the player's position. */
            a.vx -= px; b.vx -= px; c.vx -= px; d.vx -= px;
            a.vz -= pz; b.vz -= pz; c.vz -= pz; d.vz -= pz;
            draw_triangle3(&a,&c,&b, 28, 92, 52);
            draw_triangle3(&b,&c,&d, 24, 78, 45);
        }
    }
}

static void draw_box(int wx, int wy, int wz, int size, int r, int g, int b) {
    SVECTOR v[8];
    int i;
    for (i=0;i<8;i++) {
        v[i].vx = (short)(cube[i].vx * size / 16 + wx - px);
        v[i].vy = (short)(cube[i].vy * size / 16 + wy);
        v[i].vz = (short)(cube[i].vz * size / 16 + wz - pz);
        v[i].pad = 0;
    }
    /* Front and side faces, split into triangles. */
    draw_triangle3(&v[4],&v[5],&v[6],r,g,b);
    draw_triangle3(&v[4],&v[6],&v[7],r,g,b);
    draw_triangle3(&v[1],&v[5],&v[6],r*3/4,g*3/4,b*3/4);
    draw_triangle3(&v[1],&v[6],&v[2],r*3/4,g*3/4,b*3/4);
    draw_triangle3(&v[0],&v[4],&v[7],r/2,g/2,b/2);
    draw_triangle3(&v[0],&v[7],&v[3],r/2,g/2,b/2);
}

static void draw_hud(void) {
    FntPrint(-1, "VOLT TRAIL: SHARDS OF THE STORM  /  PS1\n");
    FntPrint(-1, "D-PAD MOVE  X ACTION  O CAPTURE  START RESET\n");
    FntPrint(-1, "AREA: %s   BADGES: %d/1   TEAM: %d\n", region==0?"SUNMEADOW":(region==1?"CRYSTAL PASS":"STORM ARENA"), badges, 1+caught_mosslet);
    FntPrint(-1, "SPARKIT Lv.%d HP %d/24%s\n", companion_level, companion_hp, evolved?"  -> VOLTIGON":"");
    if (game_mode == 0) {
        FntPrint(-1, "Explore, find creatures and challenge the arena.\n");
        FntPrint(-1, "Steps: %d  Wild encounters: %d  Trainer wins: %d\n", step_count, encounter, trainer_wins);
        FntPrint(-1, "X: start a battle while exploring\n");
    } else if (game_mode == 1) {
        FntPrint(-1, "%s Lv.%d  HP %d/%d\n", encounter_kind==2?"ARENA LEADER":(encounter_kind==1?"ROGUE TRAINER":"WILD MOSSLET"), enemy_level, wild_hp, enemy_max_hp);
        FntPrint(-1, "Sparkit HP: %d/24  Capture or attack\n", companion_hp);
        FntPrint(-1, "X: THUNDER PULSE  O: CAPTURE (%d left)\n", capture_attempts);
        FntPrint(-1, "Each attack gives the opponent a turn.\n");
    } else if (game_mode == 2) {
        FntPrint(-1, "VICTORY! Press X to continue.\n");
        FntPrint(-1, "Victory! Progress lasts until reset; saving is not implemented yet.\n");
    } else if (game_mode == 3) {
        FntPrint(-1, "Your team needs a rest! Press X to recover.\n");
    }
    if (action_flash > 0) FntPrint(-1, "* %s *\n", last_action==1?"SUPER EFFECTIVE":(last_action==2?"CREATURE CAPTURED":"ACTION"));
    FntFlush(-1);
}

int main(void) {
    u_long pad;
    ResetCallback();
    InitPAD(pad_buff[0], 34, pad_buff[1], 34);
    StartPAD();
    ChangeClearPAD(0);
    ResetGraph(0);
    SetVideoMode(MODE_NTSC);
    SetDefDispEnv(&disp[0], 0, 0, SCREEN_W, SCREEN_H);
    SetDefDispEnv(&disp[1], 0, SCREEN_H, SCREEN_W, SCREEN_H);
    SetDefDrawEnv(&draw[0], 0, SCREEN_H, SCREEN_W, SCREEN_H);
    SetDefDrawEnv(&draw[1], 0, 0, SCREEN_W, SCREEN_H);
    draw[0].isbg = 1; draw[0].r0 = 10; draw[0].g0 = 15; draw[0].b0 = 35;
    draw[1].isbg = 1; draw[1].r0 = 10; draw[1].g0 = 15; draw[1].b0 = 35;
    SetDispMask(1);
    FntLoad(960, 0);
    FntOpen(8, 8, 304, 100, 0, 512);
    gte_SetGeomOffset(SCREEN_W/2, SCREEN_H/2);
    gte_SetGeomScreen(180);

    while (1) {
        db = 1 - db;
        prim_used = 0;
        ClearOTagR(ot[db], OT_LEN);
        PutDrawEnv(&draw[db]);
        /* BIOS pad buffers store button bits active-low in bytes 2 and 3. */
        pad = (u_long)(~((uint16_t)pad_buff[0][2] | ((uint16_t)pad_buff[0][3] << 8))) & 0xffff;

        if (action_flash > 0) action_flash--;
        if (pad & PAD_START) { px=0; pz=0; game_mode=0; companion_hp=24; wild_hp=16; step_count=0; region=0; badges=0; caught_mosslet=0; trainer_wins=0; companion_level=5; evolved=0; capture_attempts=3; }
        if (game_mode == 0) {
            if (pad & PAD_LEFT)  { px -= 4; facing=1; step_count++; }
            if (pad & PAD_RIGHT) { px += 4; facing=2; step_count++; }
            if (pad & PAD_UP)    { pz += 4; facing=3; step_count++; }
            if (pad & PAD_DOWN)  { pz -= 4; facing=0; step_count++; }
            if (px < -WORLD_LIMIT) px = -WORLD_LIMIT;
            if (px > WORLD_LIMIT) px = WORLD_LIMIT;
            if (pz < -WORLD_LIMIT) pz = -WORLD_LIMIT;
            if (pz > WORLD_LIMIT) pz = WORLD_LIMIT;
            if ((pad & PAD_CROSS) && step_count > 5) {
                encounter++;
                capture_attempts=3;
                enemy_turn=0;
                if (region==2 && badges==0) { encounter_kind=2; enemy_level=8; enemy_max_hp=30; wild_hp=enemy_max_hp; }
                else if ((step_count % 3)==0) { encounter_kind=1; enemy_level=4+(trainer_wins%3); enemy_max_hp=18+trainer_wins*2; wild_hp=enemy_max_hp; }
                else { encounter_kind=0; enemy_level=2+(step_count%4); enemy_max_hp=16; wild_hp=enemy_max_hp; }
                game_mode=1;
            }
            /* Region transitions are reached by exploring toward the far edge. */
            if (pz > 420 && region < 2) { region++; pz=-360; px=0; }
            if (pz < -420 && region > 0) { region--; pz=360; px=0; }
        } else if (game_mode == 1) {
            if (companion_hp <= 0) game_mode=3;
            if ((pad & PAD_CROSS) && game_mode==1) {
                int damage = evolved ? 13 : (companion_level >= enemy_level ? 10 : 7);
                wild_hp -= damage;
                last_action = (damage >= 10) ? 1 : 0; action_flash=30;
                if (wild_hp <= 0) {
                    game_mode=2;
                } else {
                    companion_hp -= (enemy_level >= companion_level ? 5 : 3);
                    if (companion_hp <= 0) game_mode=3;
                }
            }
            if ((pad & PAD_CIRCLE) && game_mode==1) {
                capture_attempts--;
                if (wild_hp <= enemy_max_hp/2 && (encounter_kind==0 || capture_attempts<=1)) {
                    if (encounter_kind==0) caught_mosslet=1;
                    last_action=2; action_flash=30; game_mode=2;
                } else {
                    companion_hp -= 2;
                    if (companion_hp <= 0) game_mode=3;
                }
            }
        } else if (game_mode == 2 && (pad & PAD_CROSS)) {
            if (encounter_kind==2) badges=1;
            else if (encounter_kind==1) trainer_wins++;
            companion_level++;
            companion_hp=24;
            if (companion_level >= 8) evolved=1;
            game_mode=0;
            if (region==0 && step_count>20) region=1;
            if (region==1 && step_count>45) region=2;
        } else if (game_mode == 3 && (pad & PAD_CROSS)) {
            companion_hp=24; game_mode=0; px=0; pz=0;
        }

        /* Camera follows the player; flat-shaded geometry is deliberately PS1-friendly. */
        MATRIX m;
        RotMatrix(&(SVECTOR){0,0,0,0}, &m);
        TransMatrix(&m, &(VECTOR){0, -10, -170});
        gte_SetRotMatrix(&m); gte_SetTransMatrix(&m);
        draw_ground();
        /* Distinct landmarks for three connected areas. */
        draw_box(-100, 5, 210, 25, 95, 65, 35);
        draw_box(-100, 30, 210, 34, 20, 125, 48);
        draw_box(115, 5, 300, 24, 95, 65, 35);
        draw_box(115, 30, 300, 32, 20, 125, 48);
        draw_box(-175, 8, 355, 18, 110, 110, 130);
        draw_box(170, 8, 390, 22, 100, 105, 125);
        if (region==1) { draw_box(-110,18,260,34,105,170,220); draw_box(110,18,315,30,100,185,230); }
        if (region==2) { draw_box(-120,20,300,42,150,60,35); draw_box(120,20,300,42,150,60,35); draw_box(0,25,360,55,235,165,40); }
        /* Player, Sparkit and wild creature use original placeholder geometry. */
        draw_box(0, 10, 90, 18, 60, 110, 235);
        draw_box(28, 7, 105, 10, 250, 205, 45);
        draw_box(28, 19, 105, 7, 250, 205, 45);
        if (evolved) draw_box(35, 27, 105, 12, 255, 145, 30);
        if (game_mode == 1) {
            draw_box(-38, 9, 135, 16, encounter_kind==2?190:75, encounter_kind==2?75:170, 90);
            if (encounter_kind==2) draw_box(-38,24,135,10,230,165,40);
        }

        draw_hud();
        DrawSync(0);
        VSync(0);
        PutDispEnv(&disp[db]);
        DrawOTag(ot[db]);
    }
    return 0;
}
